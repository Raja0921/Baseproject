package pageLocators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MKTLinkvalLocators {

	@FindBy(how=How.XPATH,using="//*[@class='cA-DD-smallTriangle']")
	public WebElement searchcardclick;
	
	@FindBy (id="cA-DD-cardsSearchInput")
	public WebElement searchcardtabclick;
	
	@FindBy(id="citi-simplicity-credit-card")
	public WebElement simplicitycardclick;
	
}

