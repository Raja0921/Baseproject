package pageActions;

import pageLocators.MKTLinkvalLocators;
import org.apache.commons.logging.Log;
import utils.SeleniumDriver;

public class MKTLinkvalActions {
	MKTLinkvalLocators MKTLinkvallocators = new MKTLinkvalLocators();
	

	public void homepage(String url) {
		log.info(">> Link Validation - Start");
		SeleniumDriver.getDriver().get(url);
		
	}

	public void clicksearchcard() {
		log.info(">> click searchcard");
		MKTLinkvallocators.searchcardclick.click();
		
	}
	
	public void clicksearchcardtab() {
		log.info(">> click searchcard tab");
		MKTLinkvallocators.searchcardtabclick.click();
		
	}

	public void entercardname(String CardName) {
		log.info(">> entercardname");
		MKTLinkvallocators.searchcardtabclick.sendKeys(CardName);
		
	}

	public void selectcard() {
		log.info(">> selectcardname");
		MKTLinkvallocators.simplicitycardclick.click();
		log.info(">> Link Validation - Start");
		
	}

	

}
